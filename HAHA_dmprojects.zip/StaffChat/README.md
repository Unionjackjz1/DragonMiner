This is a spigot plugin
use: /sc or /ac or /staffchat or /adminchat

Permission to use/view staffchat: Staffchat.use
